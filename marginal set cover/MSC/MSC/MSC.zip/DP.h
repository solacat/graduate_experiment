#include<iostream>
#include<string>
#include<vector>
#include<math.h>

using namespace std;