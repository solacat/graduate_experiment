#include<iostream>

using namespace std;

//get factorial of N
int factorial(int N);

//get binomial coefficient of (m,n);
int binomial(int n, int m);